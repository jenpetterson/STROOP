function Stroop
%%Copyright
%Copyright 2022 Jennifer L. Petterson

%Licensed under the Apache License, Version 2.0 (the "License");
%you may not use this file except in compliance with the License.
%You may obtain a copy of the License at

%    http://www.apache.org/licenses/LICENSE-2.0

%Unless required by applicable law or agreed to in writing, software
%distributed under the License is distributed on an "AS IS" BASIS,
%WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
%See the License for the specific language governing permissions and
%limitations under the License.
%% Initial Setup
%u is red, i is green, o is blue, p is yellow.
%Colors and words
colors={'BLUE' 'RED' 'GREEN' 'YELLOW'};
codes=['b' 'r' 'g' 'y'];
ASCII=[111 117 105 112];
%On screen instructions for each task 
q={'U=Red I=Green O=Blue P=Yellow'};

%% Program start
%List dialog to choose practice or intervention
Type={'Practice','Intervention'};
[indx]=listdlg('ListString',Type,'PromptString','Select a Practice or Intervention',...
    'SelectionMode','single');
%List dialog to choose type of task 
Trials={'Simple','Interference','Switching'};
[indx1]=listdlg('ListString',Trials,'PromptString','Select a Trial Type',...
    'SelectionMode','single');

%Program runs on a while loop based on the choices from the first two 
%list dialogs
while indx<=2
    
    if indx==1 && indx1==1
%% Practice - Simple

%Choose number of trials
number=inputdlg('How many practice trials are required?');
num=str2double(number);

%set up of random order
for i=1:num
    LUT_P1(i,1)=randi([1 4]);
end

%Instructions
msg=msgbox('Click the key that corresponds to the word/color shown on screen. U=RED, I=GREEN, O=BLUE, P=YELLOW');
waitfor(msg);
pause(3);

%Base figure
fig=figure('Units','normalized','outerposition',[0 0 1 1]);
    set(gcf,'color','k');
    set(fig,'menubar','none');
    
%For loop runs through the randomly generated order of words from the look 
%up table  with matching colors for the simple naming condition for the 
%total number of chosen trials 

for i=1:num
    %axes for fixation cross
    axes2=axes('Position',[0.45 0.5 0.1 0.1],'Visible','off');
    axes2.XTick=[0 1];axes2.YTick=[0 1];
    axes2.Color='black';
    pbaspect([1 1 1]);
    
    %fixation cross
    line1=line([0 1], [0.5 0.5],'Color','white','LineWidth',15);
    line2=line([0.5 0.5],[0 1],'Color','white','LineWidth',15);
    
    pause(0.5); %cross shown for 500ms, then turns black 
    
    line1=line([0 1], [0.5 0.5],'Color','black','LineWidth',15);
    line2=line([0.5 0.5],[0 1],'Color','black','LineWidth',15);
    
    %colors and codes and correct key taken basd on look up table for 
    %simple naming condition generated at line 33 
    a=colors(LUT_P1(i,1));
    b=codes(LUT_P1(i,1));
    c=ASCII(LUT_P1(i,1));
    
    %axes for the placement of words
    axes1=axes('Units','normalized','outerposition',[0 0 1 1],'Visible','off');
    axes1.XTick=[0 1];axes1.YTick=[0 1];
    axes1.Color='black';
    tic %start timer
    
    %if else loop to decide which word and color will be shown on screen 
    if LUT_P1(i,1)==1
    t=text(0.33,0.55,a,'Color',b,'FontSize',100); %If the words are off centered 
    %on a large monitor, the first value after t=text (e.g., 0.33 above) can
    %be altered to centered the words. The scale is based on a plot of 0-1.
    %Decreasing the value will move the words to the left and increasing
    %will move the words to the right. Otherwise, the size of the text can
    %also be changed by changing value after 'FontSize'. Once you have
    %decided on a good positioning for the screen that will be used, change
    %this for each condition by finding the same lines of code and
    %adjusting to the desired location. 
    text(0.1,0.1,q,'Color',[1 1 1],'FontSize',15);
    elseif LUT_P1(i,1)==2
    t=text(0.35,0.55,a,'Color',b,'FontSize',100);
    text(0.1,0.1,q,'Color',[1 1 1],'FontSize',15);
    elseif LUT_P1(i,1)==3
    t=text(0.27,0.55,a,'Color',b,'FontSize',100);
    text(0.1,0.1,q,'Color',[1 1 1],'FontSize',15);
    elseif LUT_P1(i,1)==4
    t=text(0.26,0.55,a,'Color',b,'FontSize',100);   
    text(0.1,0.1,q,'Color',[1 1 1],'FontSize',15);
    end
    
    [H]=getkeywait(3); %waits up to 3000ms for a key to be pressed. Once 
    %key is pressed the timer ends. T is the reaction time value.
    T=toc; %end timer
    
    %In practice rounds error is shown if the correct key is not chosen 
    if H~=c
        error=errordlg('Incorrect');
        pause(0.5) %500ms delay after error is shown before moving on 
        close(error)
        LUT_P1(i,2)=nan; %if they get it wrong it is nan
    elseif H==c
        LUT_P1(i,2)=T;
    end
    delete(t); 
end
close all

    elseif indx==2 && indx1==1
%% Intervention - Simple
% Choose number of trials
number=inputdlg('How many Simple naming conditions are required in the intervention?');
num=str2double(number);

%random generation of values 1 through 4 which will correspond to correct
%colors and keys
for i=1:num
    LUT_I1(i,1)=randi([1 4]);
end

%Instructions
msg=msgbox('Click the key that corresponds to the word/color shown on screen. U=RED, I=GREEN, O=BLUE, P=YELLOW');
waitfor(msg);
pause(3);

%Base figure 
fig=figure('Units','normalized','outerposition',[0 0 1 1]);
    set(gcf,'color','k');
    set(fig,'menubar','none');

%For loop runs through the randomly generated order of words from the look 
%up table  with matching colors for the simple naming condition for the 
%total number of chosen trials 

for i=1:num
    %axes for fixation cross
    axes2=axes('Position',[0.45 0.5 0.1 0.1],'Visible','off');
    axes2.XTick=[0 1];axes2.YTick=[0 1];
    axes2.Color='black';
    pbaspect([1 1 1]);
    
    %fixation cross 
    line1=line([0 1], [0.5 0.5],'Color','white','LineWidth',15);
    line2=line([0.5 0.5],[0 1],'Color','white','LineWidth',15);
    
    pause(0.5); %cross shown for 500ms, then turns black 
    
    line1=line([0 1],[0.5 0.5],'Color','black','LineWidth',15);
    line2=line([0.5 0.5],[0 1],'Color','black','LineWidth',15);
    
    %colors and codes and correct key taken basd on look up table for 
    %simple naming condition generated at line 115
    a=colors(LUT_I1(i,1));
    b=codes(LUT_I1(i,1));
    c=ASCII(LUT_I1(i,1));
    
    %axes for the placement of words
    axes1=axes('Units','normalized','outerposition',[0 0 1 1],'Visible','off');
    axes1.XTick=[0 1];axes1.YTick=[0 1];
    axes1.Color='black';
   
    tic %start timer
    %if else loop to decide which word and color will be shown on screen 
    if LUT_I1(i,1)==1
    t=text(0.33,0.55,a,'Color',b,'FontSize',100);
    text(0.1,0.1,q,'Color',[1 1 1],'FontSize',15);
    elseif LUT_I1(i,1)==2  
    t=text(0.35,0.55,a,'Color',b,'FontSize',100);
    text(0.1,0.1,q,'Color',[1 1 1],'FontSize',15);
    elseif LUT_I1(i,1)==3
    t=text(0.27,0.55,a,'Color',b,'FontSize',100);
    text(0.1,0.1,q,'Color',[1 1 1],'FontSize',15);
    elseif LUT_I1(i,1)==4
    t=text(0.26,0.55,a,'Color',b,'FontSize',100);  
    text(0.1,0.1,q,'Color',[1 1 1],'FontSize',15);
    end
    
    [H]=getkeywait(3);%waits up to 3000ms for a key to be pressed. Once 
    %key is pressed the timer ends. T is the reaction time value.
    T=toc; %end timer
    
    %If the correct answer is given the reaction time is stored in column 2
    %of the look up table and else, the incorrect reaction time 
    %is stored in column 3
    if H~=c
        LUT_I1(i,3)=T;
        LUT_I1(i,2)=nan; 
    elseif H==c
        LUT_I1(i,2)=T;
        LUT_I1(i,3)=nan; 
    end
    delete(t);
end
close all

%Simple Data Output
%Accuracy and number of correct and incorrect answers 
count_correct=nnz(~isnan(LUT_I1(:,2)));
count_incorrect=nnz(~isnan(LUT_I1(:,3)));
Accuracy=100-((count_incorrect/count_correct)*100);

%Average of the correct and incorrect answers 
mean_I1=array2table(mean(LUT_I1(:,2),'omitnan'),'VariableNames',{'Mean Correct Reaction Time'});
mean_II1=array2table(mean(LUT_I1(:,3),'omitnan'),'VariableNames',{'Mean Incorrect Reaction Time'});
Accuracy=array2table(Accuracy,'VariableNames',{'Percentage Correct'});

%Get what words were shown into a format that can be exported
Tmp1={};
for i=1:num
    Tmp1(i,1)=colors(LUT_I1(i,1));
end

%Change data into table format for exporting to excel
Simple=cell2table(Tmp1);
Simple(:,2)=array2table(LUT_I1(:,2));
Simple(:,3)=array2table(LUT_I1(:,3));
Simple.Properties.VariableNames={'Word', 'Reaction Time - Correct', 'Reaction Time - Incorrect'};


%File Output to excel 
[file,path]=uiputfile({'*.xlsx'},'Save output as:');
writetable(mean_I1,strcat(path,file),'Sheet','Simple Condition');
writetable(mean_II1,strcat(path,file),'Sheet','Simple Condition','Range','B1');
writetable(Accuracy,strcat(path,file),'Sheet','Simple Condition','Range','C1');
writetable(Simple,strcat(path,file),'Sheet','Simple Condition','Range','A5');


    elseif indx==1 && indx1==2
        
%% Practice - Interference
% Choose number of trials
number=inputdlg('How many practice trials are required?');
num=str2double(number);

%random generation of values 1 through 4 which will correspond to correct
%words, colors and keys
for i=1:num
    LUT_P2(i,1)=randi([1 4]);
    LUT_P2(i,2)=randi([1 4]);
end

%Instructions
msg=msgbox('Click the key that corresponds to the COLOR of the word shown on screen. U=RED, I=GREEN, O=BLUE, P=YELLOW');
waitfor(msg);
pause(3);

%Base figure 
fig=figure('Units','normalized','outerposition',[0 0 1 1]);
    set(gcf,'color','k');
    set(fig,'menubar','none');
    
%For loop runs through the randomly generated order of words from the look 
%up table with incongruent or congruent word and color combinations for the 
%total number of chosen trials 

for i=1:num
    %axes for fixation cross
    axes2=axes('Position',[0.45 0.5 0.1 0.1],'Visible','off');
    axes2.XTick=[0 1];axes2.YTick=[0 1];
    axes2.Color='black';
    pbaspect([1 1 1]);
    
    %fixation cross 
    line1=line([0 1], [0.5 0.5],'Color','white','LineWidth',15);
    line2=line([0.5 0.5],[0 1],'Color','white','LineWidth',15);
    
    pause(0.5); %cross shown for 500ms, then turns black 
    
    line1=line([0 1], [0.5 0.5],'Color','black','LineWidth',15);
    line2=line([0.5 0.5],[0 1],'Color','black','LineWidth',15);
    
    %colors and codes and correct key taken basd on look up table for 
    %simple naming condition generated at line 239
    a=colors(LUT_P2(i,1));
    b=codes(LUT_P2(i,2));
    c=ASCII(LUT_P2(i,2));
    
    %axes for the placement of words
    axes1=axes('Units','normalized','outerposition',[0 0 1 1],'Visible','off');
    axes1.XTick=[0 1];axes1.YTick=[0 1];
    axes1.Color='black';
    
    tic%start timer
    %if else loop to decide which word and color will be shown on screen 
    if LUT_P2(i,1)==1
    t=text(0.33,0.55,a,'Color',b,'FontSize',100);
    text(0.1,0.1,q,'Color',[1 1 1],'FontSize',15);
    elseif LUT_P2(i,1)==2
    t=text(0.35,0.55,a,'Color',b,'FontSize',100);
    text(0.1,0.1,q,'Color',[1 1 1],'FontSize',15);
    elseif LUT_P2(i,1)==3
    t=text(0.27,0.55,a,'Color',b,'FontSize',100);
    text(0.1,0.1,q,'Color',[1 1 1],'FontSize',15);
    elseif LUT_P2(i,1)==4
    t=text(0.26,0.55,a,'Color',b,'FontSize',100);
    text(0.1,0.1,q,'Color',[1 1 1],'FontSize',15);
    end
  
    [H]=getkeywait(3);%waits up to 3000ms for a key to be pressed. Once 
    %key is pressed the timer ends. T is the reaction time value.
    T=toc; %end timer
    
    %In practice rounds error is shown if the correct key is not chosen 
    if H~=c
        error=errordlg('Incorrect');
        pause(0.5) %500ms delay after error is shown before moving on 
        close(error)
        LUT_P2(i,3)=nan;
    elseif H==c
        LUT_P2(i,3)=T;
    end
    delete(t);
end
close all

    elseif indx==2 && indx1==2
        
%% Intervention - Interference 
% Choose number of trials
number=inputdlg('How many Interference conditions are required in the intervention');
num1=str2double(number);

%random generation of values 1 through 4 which will correspond to correct
%colors and keys
for i=1:num1
    LUT_I2(i,1)=randi([1 4]);
    LUT_I2(i,2)=randi([1 4]);
end

%Instructions
msg=msgbox('Click the key that corresponds to the COLOR of the word shown on screen. U=RED, I=GREEN, O=BLUE, P=YELLOW');
waitfor(msg);
pause(3);

%Base Figure
fig=figure('Units','normalized','outerposition',[0 0 1 1]);
    set(gcf,'color','k');
    set(fig,'menubar','none');
    
%For loop runs through the randomly generated order of words from the look 
%up table with incongruent or congruent word and color combinations for the 
%total number of chosen trials 
for i=1:num1
    %axes for fixation cross
    axes2=axes('Position',[0.45 0.5 0.1 0.1],'Visible','off');
    axes2.XTick=[0 1];axes2.YTick=[0 1];
    axes2.Color='black';
    pbaspect([1 1 1]);
    
    %fixation cross 
    line1=line([0 1], [0.5 0.5],'Color','white','LineWidth',15);
    line2=line([0.5 0.5],[0 1],'Color','white','LineWidth',15);
    
    pause(0.5); %cross shown for 500ms, then turns black 
    
    line1=line([0 1], [0.5 0.5],'Color','black','LineWidth',15);
    line2=line([0.5 0.5],[0 1],'Color','black','LineWidth',15);
    
    %colors and codes and correct key taken basd on look up table for 
    %simple naming condition generated at line 327
    a=colors(LUT_I2(i,1));
    b=codes(LUT_I2(i,2));
    c=ASCII(LUT_I2(i,2));
    
    axes1=axes('Units','normalized','outerposition',[0 0 1 1],'Visible','off');
    axes1.XTick=[0 1];axes1.YTick=[0 1];
    axes1.Color='black';
    
    tic %start timer
    %if else loop to decide which word and color will be shown on screen
    if LUT_I2(i,1)==1
    t=text(0.33,0.55,a,'Color',b,'FontSize',100);
    text(0.1,0.1,q,'Color',[1 1 1],'FontSize',15);
    elseif LUT_I2(i,1)==2
    t=text(0.35,0.55,a,'Color',b,'FontSize',100);
    text(0.1,0.1,q,'Color',[1 1 1],'FontSize',15);
    elseif LUT_I2(i,1)==3
    t=text(0.27,0.55,a,'Color',b,'FontSize',100);
    text(0.1,0.1,q,'Color',[1 1 1],'FontSize',15);
    elseif LUT_I2(i,1)==4
    t=text(0.26,0.55,a,'Color',b,'FontSize',100);   
    text(0.1,0.1,q,'Color',[1 1 1],'FontSize',15);
    end
  
    [H]=getkeywait(3); %waits up to 3000ms for a key to be pressed. Once 
    %key is pressed the timer ends. T is the reaction time value.
    T=toc; %end timer
    
    %If the correct answer is given the reaction time is stored in column 3
    %of the look up table and else, the incorrect reaction time 
    %is stored in column 4
    if H~=c
        LUT_I2(i,4)=T;
        LUT_I2(i,3)=nan;
    elseif H==c
        LUT_I2(i,3)=T;
        LUT_I2(i,4)=nan;
    end
    delete(t);
    
end
close all 

%Interference Data Output 

%Accuracy and number of correct and incorrect answers 
count_correct=nnz(~isnan(LUT_I2(:,3)));
count_incorrect=nnz(~isnan(LUT_I2(:,4)));
Accuracy=100-((count_incorrect/count_correct)*100);

%Average of the correct and incorrect answers 
mean_I2=array2table(mean(LUT_I2(:,3),'omitnan'),'VariableNames',{'Mean Correct Reaction Time'});
mean_II2=array2table(mean(LUT_I2(:,4),'omitnan'),'VariableNames',{'Mean Incorrect Reaction Time'});
Accuracy=array2table(Accuracy,'VariableNames',{'Percentage Correct'});

%Get congruence/incongruence of words and colors
tmp1={};
for i=1:num1
    if LUT_I2(i,1)==LUT_I2(i,2)
       tmp1(i,1)={'Congruent'};
       tmp2(i,1)=1;
    else
       tmp1(i,1)={'Incongruent'};
       tmp2(i,1)=0;
    end
end

%Get average reaction time for congruent and incongruent trials
c2=array2table(mean(LUT_I2((tmp2(:,1)==1),3),'omitnan'),'VariableNames',{'Mean Congruent Reaction Time'});
ic2=array2table(mean(LUT_I2((tmp2(:,1)==0),3),'omitnan'),'VariableNames',{'Mean Incongruent Reaction Time'});

%Get what words were shown and what colors they were into a format that can be exported
Tmp1={};
for i=1:num1
    Tmp1(i,1)=colors(LUT_I2(i,1));
    Tmp1(i,2)=colors(LUT_I2(i,2));
    Tmp1(i,3)=tmp1(i,1);
end

%Change data into table format for exporting to excel
Interference=cell2table(Tmp1);
Interference(:,4)=array2table(LUT_I2(:,3));
Interference(:,5)=array2table(LUT_I2(:,4));
Interference.Properties.VariableNames={'Word', 'Word Color', 'Congruence', 'Reaction Time - Correct', 'Reaction Time - Incorrect'};


%File Output Interference
[file,path]=uiputfile({'*.xlsx'},'Save output as:');

writetable(mean_I2,strcat(path,file),'Sheet','Interference Condition');
writetable(mean_II2,strcat(path,file),'Sheet','Interference Condition','Range','B1');
writetable(c2,strcat(path,file),'Sheet','Interference Condition','Range','C1');
writetable(ic2,strcat(path,file),'Sheet','Interference Condition','Range','D1');
writetable(Accuracy,strcat(path,file),'Sheet','Interference Condition','Range','E1');
writetable(Interference,strcat(path,file),'Sheet','Interference Condition',...
    'Range','A5');

    elseif indx==1 && indx1==3
%% Practice - Switching

%Choose number of trials
number=inputdlg('How many simple naming practice trials are required in the Switching practice?');
num=str2double(number);
number=inputdlg('How many Interference naming practice trials are required in the Switching practice?');
num1=str2double(number);

%Set up of random order of colors and words - this organizes a matrix so
%that naming versus interference conditions will be randomly interspersed
%through 
tmp=repmat(ones,1,num);tmp2=repmat(2,1,num1);tmp3=[tmp tmp2];
num2=num+num1;

[~,n] = size(tmp3) ;idx = randperm(n) ;
tmp4 = tmp3 ;tmp4(1,idx) = tmp3(1,:);tmp5=tmp4';

for i=1:num2
    LUT_P3(i,1)=randi([1 4]);
    LUT_P3(i,2)=randi([1 4]);
end
LUT_P3=[LUT_P3 tmp5];

%Instructions
msg=msgbox('IF a CROSS is shown, click the key that corresponds to the COLOR of the word shown on screen. IF a SQUARE is shown, click the key that corresponds to the WORD that is shown on screen. U=RED, I=GREEN, O=BLUE, P=YELLOW');
waitfor(msg);
pause(3);

%Base figure 
fig=figure('Units','normalized','outerposition',[0 0 1 1]);
    set(gcf,'color','k');
    set(fig,'menubar','none');

%For loop runs through the randomly generated order of words from the look 
%up table  with congruent or incongruent words and colors. Within the for loop 
%if the third column of the look up table is a 2 this corresponds to an
%interference condition and a cross will be shown before the word. If the
%value is a 1, this corresponds to a simple naming condition and a square
%is shown.
for i=1:num2
    
    %Interference (correct answer is the color of the word)
    if LUT_P3(i,3)==2
        
    %axes for fixation cross
    axes2=axes('Position',[0.45 0.5 0.1 0.1],'Visible','off');
    axes2.XTick=[0 1];axes2.YTick=[0 1];
    axes2.Color='black';
    pbaspect([1 1 1]);
    
    %fixation cross 
    line1=line([0 1], [0.5 0.5],'Color','white','LineWidth',15);
    line2=line([0.5 0.5],[0 1],'Color','white','LineWidth',15);
    
    pause(0.5); %cross shown for 500ms, then turns black
    
    line1=line([0 1], [0.5 0.5],'Color','black','LineWidth',15);
    line2=line([0.5 0.5],[0 1],'Color','black','LineWidth',15);
    
    %colors and codes and correct key taken based on look up table
    a=colors(LUT_P3(i,1));
    b=codes(LUT_P3(i,2));
    c=ASCII(LUT_P3(i,2));
    
    %axes for the placement of words
    axes1=axes('Units','normalized','outerposition',[0 0 1 1],'Visible','off');
    axes1.XTick=[0 1];axes1.YTick=[0 1];
    axes1.Color='black';
    
    tic %start timer
    %if else loop to decide which word and color will be shown on screen
    if LUT_P3(i,1)==1
    t=text(0.33,0.55,a,'Color',b,'FontSize',100);
    text(0.1,0.1,q,'Color',[1 1 1],'FontSize',15);
    elseif LUT_P3(i,1)==2
    t=text(0.35,0.55,a,'Color',b,'FontSize',100);
    text(0.1,0.1,q,'Color',[1 1 1],'FontSize',15);
    elseif LUT_P3(i,1)==3
    t=text(0.27,0.55,a,'Color',b,'FontSize',100);
    text(0.1,0.1,q,'Color',[1 1 1],'FontSize',15);
    elseif LUT_P3(i,1)==4
    t=text(0.26,0.55,a,'Color',b,'FontSize',100);   
    text(0.1,0.1,q,'Color',[1 1 1],'FontSize',15);
    end
  
    [H]=getkeywait(3); %waits up to 3000ms for a key to be pressed. Once 
    %key is pressed the timer ends. T is the reaction time value.
    T=toc; %end timer
    
    %In practice rounds error is shown if the correct key is not chosen 
    if H~=c
        error=errordlg('Incorrect');
        pause(0.5) %500ms delay before moving on 
        close(error)
        LUT_P3(i,4)=nan;
    elseif H==c
        LUT_P3(i,4)=T;
    end
    delete(t);
    
    %Simple condition (correct answer is the name of the word)
    elseif LUT_P3(i,3)==1
        
    %axes for fixation square
    axes2=axes('Position',[0.45 0.5 0.1 0.1]);
    axes2.XTick=[0 1];axes2.YTick=[0 1];
    axes2.Color='black';
    pbaspect([1 1 1]);
    
    %Fixation square
    axes2.Color='white';
    
    pause(0.5); %square shown for 500ms, then turns black
    
    axes2.Color='black';
    
    %colors and codes and correct key taken based on look up table
    a=colors(LUT_P3(i,1));
    b=codes(LUT_P3(i,2));
    c=ASCII(LUT_P3(i,1));
    
    %axes for alignment of words
    axes1=axes('Units','normalized','outerposition',[0 0 1 1],'Visible','off');
    axes1.XTick=[0 1];axes1.YTick=[0 1];
    axes1.Color='black';
    
    tic %start timer
    %if else loop to decide which word and color will be shown on screen
    if LUT_P3(i,1)==1
    t=text(0.33,0.55,a,'Color',b,'FontSize',100);
    text(0.1,0.1,q,'Color',[1 1 1],'FontSize',15);
    elseif LUT_P3(i,1)==2
    t=text(0.35,0.55,a,'Color',b,'FontSize',100);
    text(0.1,0.1,q,'Color',[1 1 1],'FontSize',15);
    elseif LUT_P3(i,1)==3
    t=text(0.27,0.55,a,'Color',b,'FontSize',100);
    text(0.1,0.1,q,'Color',[1 1 1],'FontSize',15);
    elseif LUT_P3(i,1)==4
    t=text(0.26,0.55,a,'Color',b,'FontSize',100);   
    text(0.1,0.1,q,'Color',[1 1 1],'FontSize',15);
    end
  
    [H]=getkeywait(3); %waits up to 3000ms for a key to be pressed. Once 
    %key is pressed the timer ends. T is the reaction time value.
    T=toc; %end timer
    
    %In practice rounds error is shown if the correct key is not chosen 
    if H~=c
        error=errordlg('Incorrect');
        pause(0.5) %500ms delay before moving on 
        close(error)
        LUT_P3(i,4)=nan;
    elseif H==c
        LUT_P3(i,4)=T;
    end
    delete(t); 
    end
end
close all 
    
    elseif indx==2 && indx1==3
%% Intervention - Switching
% Choose number of trials
number=inputdlg('How many Simple naming conditions are required in the Switching task?');
num2=str2double(number);
number=inputdlg('How many Interference naming conditions are required in the Switching task?');
num3=str2double(number);

%Set up of random order of colors and words - this organizes a matrix so
%that naming versus interference conditions will be randomly interspersed
%through 
tmp=repmat(ones,1,num2);tmp2=repmat(2,1,num3);tmp3=[tmp tmp2];
num4=num2+num3;

[~,n] = size(tmp3) ;idx = randperm(n) ;
tmp4 = tmp3 ;tmp4(1,idx) = tmp3(1,:);tmp5=tmp4';

for i=1:num4
    LUT_I3(i,1)=randi([1 4]);
    LUT_I3(i,2)=randi([1 4]);
end
LUT_I3=[LUT_I3 tmp5];

%Instructions
msg=msgbox('IF a CROSS is shown, click the key that corresponds to the COLOR of the word shown on screen. IF a SQUARE is shown, click the key that corresponds to the WORD that is shown on screen. U=RED, I=GREEN, O=BLUE, P=YELLOW');
waitfor(msg);
pause(3);

%Base figure
fig=figure('Units','normalized','outerposition',[0 0 1 1]);
    set(gcf,'color','k');
    set(fig,'menubar','none');

%For loop runs through the randomly generated order of words from the look 
%up table  with congruent or incongruent words and colors. Within the for loop 
%if the third column of the look up table is a 2 this corresponds to an
%interference condition and a cross will be shown before the word. If the
%value is a 1, this corresponds to a simple naming condition and a square
%is shown.
for i=1:num4
    
    %Interference (correct answer is the color of the word)
    if LUT_I3(i,3)==2
        
    %axes for fixation cross    
    axes2=axes('Position',[0.45 0.5 0.1 0.1],'Visible','off');
    axes2.XTick=[0 1];axes2.YTick=[0 1];
    axes2.Color='black';
    pbaspect([1 1 1]);
    
    %fixation cross 
    line1=line([0 1], [0.5 0.5],'Color','white','LineWidth',15);
    line2=line([0.5 0.5],[0 1],'Color','white','LineWidth',15);
    
    pause(0.5); %cross shown for 500ms, then turns black 
    
    line1=line([0 1], [0.5 0.5],'Color','black','LineWidth',15);
    line2=line([0.5 0.5],[0 1],'Color','black','LineWidth',15);
    
    %colors and codes and correct key taken based on look up table
    a=colors(LUT_I3(i,1));
    b=codes(LUT_I3(i,2));
    c=ASCII(LUT_I3(i,2));
    
    %axes for the placement of words
    axes1=axes('Units','normalized','outerposition',[0 0 1 1],'Visible','off');
    axes1.XTick=[0 1];axes1.YTick=[0 1];
    axes1.Color='black';
    
    tic %start timer
    %if else loop to decide which word and color will be shown on screen
    if LUT_I3(i,1)==1
    t=text(0.33,0.55,a,'Color',b,'FontSize',100);
    text(0.1,0.1,q,'Color',[1 1 1],'FontSize',15);
    elseif LUT_I3(i,1)==2
    t=text(0.35,0.55,a,'Color',b,'FontSize',100);
    text(0.1,0.1,q,'Color',[1 1 1],'FontSize',15);
    elseif LUT_I3(i,1)==3
    t=text(0.27,0.55,a,'Color',b,'FontSize',100);
    text(0.1,0.1,q,'Color',[1 1 1],'FontSize',15);
    elseif LUT_I3(i,1)==4
    t=text(0.26,0.55,a,'Color',b,'FontSize',100);   
    text(0.1,0.1,q,'Color',[1 1 1],'FontSize',15);
    end
  
    [H]=getkeywait(3); %waits up to 3000ms for a key to be pressed. Once 
    %key is pressed the timer ends. T is the reaction time value.
    T=toc; %end timer
    
    %If the correct answer is given the reaction time is stored in column 4
    %of the look up table and else, the incorrect reaction time 
    %is stored in column 5
    if H~=c
        LUT_I3(i,5)=T;
        LUT_I3(i,4)=nan;
    elseif H==c
        LUT_I3(i,4)=T;
        LUT_I3(i,5)=nan;
    end
    delete(t);
    
    %Simple condition (correct answer is the name of the word)
    elseif LUT_I3(i,3)==1
        
    %axes for fixation square    
    axes2=axes('Position',[0.45 0.5 0.1 0.1]);
    axes2.XTick=[0 1];axes2.YTick=[0 1];
    axes2.Color='black';
    pbaspect([1 1 1]);
    
    %fixation square
    axes2.Color='white';
    
    pause(0.5); %waits 500ms, then square turns black
    
    axes2.Color='black';
    
    %colors and codes and correct key taken based on look up table
    a=colors(LUT_I3(i,1));
    b=codes(LUT_I3(i,2));
    c=ASCII(LUT_I3(i,1));
    
    %axes for the placement of words
    axes1=axes('Units','normalized','outerposition',[0 0 1 1],'Visible','off');
    axes1.XTick=[0 1];axes1.YTick=[0 1];
    axes1.Color='black';
    
    tic %start timer
    %if else loop to decide which word and color will be shown on screen
    if LUT_I3(i,1)==1
    t=text(0.33,0.55,a,'Color',b,'FontSize',100);
    text(0.1,0.1,q,'Color',[1 1 1],'FontSize',15);
    elseif LUT_I3(i,1)==2
    t=text(0.35,0.55,a,'Color',b,'FontSize',100);
    text(0.1,0.1,q,'Color',[1 1 1],'FontSize',15);
    elseif LUT_I3(i,1)==3
    t=text(0.27,0.55,a,'Color',b,'FontSize',100);
    text(0.1,0.1,q,'Color',[1 1 1],'FontSize',15);
    elseif LUT_I3(i,1)==4
    t=text(0.26,0.55,a,'Color',b,'FontSize',100);   
    text(0.1,0.1,q,'Color',[1 1 1],'FontSize',15);
    end
  
    [H]=getkeywait(3); %waits up to 3000ms for a key to be pressed. Once 
    %key is pressed the timer ends. T is the reaction time value.
    T=toc; %end timer
    
    %If the correct answer is given the reaction time is stored in column 4
    %of the look up table and else, the incorrect reaction time 
    %is stored in column 5
    if H~=c
        LUT_I3(i,5)=T;
        LUT_I3(i,4)=nan;
    elseif H==c
        LUT_I3(i,4)=T;
        LUT_I3(i,5)=nan;
    end
    delete(t); 
    end
end
close all 

%Data Output Switching 

%Get congruence/incongruence of words and colors
tmp3={};
for i=1:num4
    if LUT_I3(i,1)==LUT_I3(i,2)
       tmp3(i,1)={'Congruent'};
       tmp4(i,1)=1;
    else
       tmp3(i,1)={'Incongruent'};
       tmp4(i,1)=0;
    end
end

%Accuracy and number of correct and incorrect answers 
count_correct=nnz(~isnan(LUT_I3(:,4)));
count_incorrect=nnz(~isnan(LUT_I3(:,5)));
Accuracy=100-((count_incorrect/count_correct)*100);

%Average of the correct and incorrect answers and congruent vs incongruent
%trials
mean_I3=array2table(mean(LUT_I3(:,4),'omitnan'),'VariableNames',{'Mean Correct Reaction Time'});
mean_II3=array2table(mean(LUT_I3(:,5),'omitnan'),'VariableNames',{'Mean Incorrect Reaction Time'});
c3=array2table(mean(LUT_I3((tmp4(:,1)==1),4),'omitnan'),'VariableNames',{'Mean Congruent Reaction Time'});
ic3=array2table(mean(LUT_I3((tmp4(:,1)==0),4),'omitnan'),'VariableNames',{'Mean Incongruent Reaction Time'});
Accuracy=array2table(Accuracy,'VariableNames',{'Percentage Correct'});

%Get what words and colors were shown into a format that can be exported
Tmp2={};
for i=1:num4
if LUT_I3(i,3)==2
   Tmp2(i,1)={'Color'};
elseif LUT_I3(i,3)==1
   Tmp2(i,1)={'Word'};
end
end

Tmp1={};
for i=1:num4
    Tmp1(i,1)=colors(LUT_I3(i,1));
    Tmp1(i,2)=colors(LUT_I3(i,2));
    Tmp1(i,3)=tmp3(i,1);
    Tmp1(i,4)=Tmp2(i,1);
    
end
%Change data into table format for exporting to excel
Switching=cell2table(Tmp1);
Switching(:,5)=array2table(LUT_I3(:,4));
Switching(:,6)=array2table(LUT_I3(:,5));
Switching.Properties.VariableNames={'Word', 'Word Color','Congruence','Condition','Reaction Time - Correct','Reaction Time - Incorrect'};

%File Output Switching
[file,path]=uiputfile({'*.xlsx'},'Save output as:');
writetable(mean_I3,strcat(path,file),'Sheet','Switching Condition');
writetable(mean_II3,strcat(path,file),'Sheet','Switching Condition','Range','B1');
writetable(c3,strcat(path,file),'Sheet','Switching Condition','Range','C1');
writetable(ic3,strcat(path,file),'Sheet','Switching Condition','Range','D1');
writetable(Accuracy,strcat(path,file),'Sheet','Switching Condition','Range','E1');
writetable(Switching,strcat(path,file),'Sheet','Switching Condition',...
    'Range','A5');
    end

%While loop breaks if finished is selected
Type={'Practice','Intervention','Finished'};
[indx]=listdlg('ListString',Type,'PromptString','Select a Practice or Intervention',...
    'SelectionMode','single');
    if indx==3
        break
    else
Trials={'Simple','Interference','Switching'};
[indx1]=listdlg('ListString',Trials,'PromptString','Select a Trial Type',...
    'SelectionMode','single');
    end
end  

